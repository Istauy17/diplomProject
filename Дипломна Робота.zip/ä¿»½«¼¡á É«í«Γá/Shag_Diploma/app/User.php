<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Order;
use App\Favorite;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = [
'firstname','lastname', 'email', 'password', 'phone','address','postcode','City','country','role_id'];



public function Favorite()
{

return $this->hasMany(Favorite::class,'user_id','id');

}
public function History_Order()
{

return $this->hasMany(History_Order::class,'user_id','id');

}

public function Roles()
{

return $this->belongsTo(Role::class,'role_id','id');

}


public function favorite_counter ()
{
    $session_Value=session('name_session');
    $user_in_session=$this->where('email',$session_Value)->get();
    $temp_ID=0;
    foreach($user_in_session as $i)
    {
        $temp_ID=$i->id;

    } 
    $model_F=Favorite::where('user_id',$temp_ID)->count();
    return $model_F;

}
public function order_counter ()
{
    $session_Value=session('name_session');
    $user_in_session=$this->where('email',$session_Value)->get();
    $temp_ID=0;
    foreach($user_in_session as $i)
    {
        $temp_ID=$i->id;

    } 
    $model_O=Order::where('user_id',$temp_ID)->count();
    return $model_O;

}
public function total()
{

    $session_Value=session('name_session');
    $user_in_session=$this->where('email',$session_Value)->get();
    $temp_ID=0;
    foreach($user_in_session as $i)
    {
        $temp_ID=$i->id;

    } 
    $total=Order::where('user_id',$temp_ID)->sum('total');
    return $total;
}

public function hower_cart()
{

    $session_Value=session('name_session');
    $user_in_session=$this->where('email',$session_Value)->get();
    $temp_ID=0;
    foreach($user_in_session as $i)
    {
        $temp_ID=$i->id;

    } 
$hover_cart=Order::where('user_id',$temp_ID)->get();

return $hover_cart;

}
}
