<?php

namespace App;
use App\Product;

use Illuminate\Database\Eloquent\Model;

class Description extends Model
{
    
    public function Product_Counter($id)
    {
        $product = Product::find($id);
        $product->counter += 1;
        $product->save();
    }
}
