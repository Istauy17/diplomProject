<?php

namespace App;
use App\Product;
use App\Order;
use Illuminate\Database\Eloquent\Model;

class History_Order extends Model
{

    protected $table='histori_orders';
    protected $fillable = [
        'user_id','product_id', 'quentities', 'total','created_at','updated_at','status_order'
    ];

    public function Products()
    {

return $this->belongsTo(Product::class,'product_id','id');

    }


    public function Users()
    {

return $this->belongsTo(User::class,'user_id','id');

    }




    public function History_out()
    {
    
        $session_Value=session('name_session');
        $user_in_session=User::where('email',$session_Value)->get();
        $temp_ID=0;
        foreach($user_in_session as $i)
        {
            $temp_ID=$i->id;
    
        }
    
        $product=$this->where('user_id',$temp_ID)->get();
    
        return  $product;
    
    }
    public function DeleteHistori($id)
{
    $order=$this->find($id);
$order->delete();


}
}
