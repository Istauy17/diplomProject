<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\History_Order;
use Illuminate\Support\Facades\DB;

class Order extends Model
{
    protected $fillable = [
        'user_id','product_id', 'quentities', 'total', 'order_status'
    ];

    public function Products()
    {

return $this->belongsTo(Product::class,'product_id','id');

    }



    public function update_order_status($temp_ID)
    {
        $product_update=$this->where('user_id',$temp_ID)->update(['order_status'=>1]);


    }

    public function update_order()
    {
        
        $session_Value=session('name_session');
        $user_in_session=User::where('email',$session_Value)->get();
        $temp_ID=0;
        foreach($user_in_session as $i)
        {
            $temp_ID=$i->id;
    
        }
       $this->update_order_status( $temp_ID);
       $product=$this->where('user_id',$temp_ID)->where('order_status',1)->get();
        
       
       $a=0;
       $b=0;
       $c=0;
       $d=0;
       
       foreach($product as $i)
       {
        $a=$i->user_id;
        $b=$i->product_id;
        $c=$i->quentities;
        $d=$i->total;
   

       History_Order::create([ 
            'product_id'=>$b,
            'user_id'=>$a,
           'quentities'=>$c,
           'total'=>$d,
        ]);
       }
    
       
        $product=$this->where('user_id',$temp_ID)->delete();

    }

   



}
