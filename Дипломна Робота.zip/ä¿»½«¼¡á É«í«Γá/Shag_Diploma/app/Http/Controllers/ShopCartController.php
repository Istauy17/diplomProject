<?php

namespace App\Http\Controllers;

use App\Order;
use Illuminate\Http\Request;
use App\User;
use App\ShopingCart;
use App\Product;
class ShopCartController extends Controller
{
    public function index()
    {
        $session_Value=session('name_session');
        $user_in_session=User::where('email',$session_Value)->get();
        $temp_ID=0;
        foreach($user_in_session as $i)
        {
            $temp_ID=$i->id;

        }
        $product_id=Order::where('user_id',$temp_ID)->get();


        $helper= new User();

        return view('ShopingCart.ST_ShopingCart',['product_id'=>$product_id,
        'favorite_counter'=>$helper->favorite_counter(),
        'order_counter'=>$helper->order_counter(),
        'total'=>$helper->total(),
        'hover_cart'=>$helper->hower_cart()]);
    } 
    
    public function create_cart($id)
    {
        if(session('name_session'))
        {
            $session_Value=session('name_session');
            $user_in_session=User::where('email',$session_Value)->get();
            $temp_ID=0;
            foreach($user_in_session as $i)
            {
                $temp_ID=$i->id;
    
            }
    
            $product=Product::where('id',$id)->get();
           $temp_P_price=0;
          
             foreach($product as $i)
            {
                $temp_P_price=$i->prise;
    
            }
    
           
             $userCheck = Order::where([
                'user_id' => $temp_ID,
                'product_id'=>$id
            ])->get();
               
            if($userCheck->count())
            {
                return redirect()->back()->with('info',"Товар вже існує");
           }
        
           ShopingCart::create([
            'product_id'=>$id,
            'user_id'=>$temp_ID,
           'quentities'=>1,
           'total'=>$temp_P_price,
        ]);
            
           return redirect()->back()->with('info',"Товар добавлено");
        }

        return redirect()->route('login')->with('info',"Авторизуйтесь");

    }
    public function delete($id)
    {
$order=Order::find($id);
$order->delete();
return redirect()->back()->with('info',"Видалено з корзини");
    }

    public function updateCart(Request $request)
    {
        
        $session_Value=session('name_session');
            $user_in_session=User::where('email',$session_Value)->get();
            $temp_ID=0;
            foreach($user_in_session as $i)
            {
                $temp_ID=$i->id;
    
            }
        $i = 0;
        $product = ShopingCart::where('user_id',$temp_ID)->get();
        foreach($product as $p)
        {
            $p->update(['quentities'=>$request->input('quentities')[$i]]);
            $i++;
        }

        
        return redirect()->back();
        
    }


}
