<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Order;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\Auth;
use App\Favorite;
use App\History_Order;

class AccountController extends Controller
{
public function index()
{
    $H=new History_Order();
    $F=new Favorite();
    $session_Value=session('name_session');
    $user_in_session=User::where('email',$session_Value)->get();
    if(!session('name_session')){
        return redirect()->route('login')->with('info',"Для того чтобы зайти в кабинет нужно авторизироваться");
    }
    $helper= new User();

    return view('Account.ST_Account',
    ['user_in_session'=>$user_in_session,
    'favorite'=>$F->Favorite_out(),
    'History_Order'=>$H->History_out(),
    'favorite_counter'=>$helper->favorite_counter(),
    'order_counter'=>$helper->order_counter(),
    'total'=>$helper->total(),
    'hover_cart'=>$helper->hower_cart()
    ]);
}


public function postEditInfo(Request $request )
{
    $session_Value=session('name_session');
    $user_in_session=User::where('email',$session_Value)->get();
    $temp_ID=0;
    foreach($user_in_session as $i)
    {
        $temp_ID=$i->id;

    }

   

$tempInfo=User::find($temp_ID) ;
 $tempInfo->firstname=$request->get('firstname');
 $tempInfo->lastname=$request->get('lastname');
 $tempInfo->email=$request->get('email');
 $tempInfo->phone=$request->get('phone');
 $tempInfo->address=$request->get('address');
 $tempInfo->country=$request->get('country');
 $tempInfo->postcode=$request->get('postcode');
 $tempInfo->City=$request->get('city');

 $tempInfo->save();
 return redirect()->route('Account')->with('info',"Ви успішно редагували данні");

}

public function out(Request $request)
{
Auth::logout();
$request->session()->forget('name_session');
$request->session()->forget('admin_session');
return redirect()->route('index_main');

}

}

