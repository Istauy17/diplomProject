<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Favorite;
use App\User;

class Favorite_Controller extends Controller
{
    
    public function index()
    {
    $F=new Favorite();
    $helper= new User();
    return view('Favorite.ST_Favorite',['favorite'=>$F->Favorite_out(),
    'favorite_counter'=>$helper->favorite_counter(),
    'order_counter'=>$helper->order_counter(),
    'total'=>$helper->total(),
    'hover_cart'=>$helper->hower_cart()
    ] );
    
    }

    
    public function AddFavorite($id)
    {

        if(session('name_session'))
        {
        $session_Value=session('name_session');
        $user_in_session=User::where('email',$session_Value)->get();
        $temp_ID=0;
        foreach($user_in_session as $i)
        {
            $temp_ID=$i->id;

        }

       
    
         $userCheck = Favorite::where([
            'user_id' => $temp_ID,
            'product_id'=>$id
        ])->get();
           
        if($userCheck->count())
        {
            return redirect()->back()->with('info',"Товар вже існує");
       }
    
       $F=new Favorite();

                $F->Add_Favorite($id);
                return redirect()->back()->with('info','Добавлено в избранные');

    
        
       return redirect()->back()->with('info',"Товар добавлено");
        }


        return redirect()->route('login')->with('info',"Авторизуйтесь");
            
               

        
        

    }

    public function DeleteFavorite($id)
    {
        $F=new Favorite();
        $F->Delete_Favorite($id);
    return redirect()->back()->with('info',"Видалено з Избранных");
    }
    
}
