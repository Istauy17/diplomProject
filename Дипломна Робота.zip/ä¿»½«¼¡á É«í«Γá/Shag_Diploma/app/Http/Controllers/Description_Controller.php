<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Product;
use App\Collection;
use App\Brand;
use App\Description;

class Description_Controller extends Controller
{
    public function index($id)
    {
    $cloth=Product::where('id',$id)->get();
    $karusel=Product::all();
    $collection = Collection::all();
    $counter = new Description();
    $counter->Product_Counter($id);
    $productTop = Product::orderBy('counter','desc')->take(7)->get();
$brand = Brand::all();
    $helper= new User();
    return view('Description.ST_Descriptions',
    ['cloth'=>$cloth,
    'karusel'=>$karusel,
    'favorite_counter'=>$helper->favorite_counter(),
    'order_counter'=>$helper->order_counter(),
    'total'=>$helper->total(),
    'hover_cart'=>$helper->hower_cart(),
    'brand'=>$brand,
'collection'=>$collection,
'productTop'=>$productTop]);
    
}
}
