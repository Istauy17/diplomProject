<?php

namespace App\Http\Controllers;

use App\History_Order;
use Illuminate\Http\Request;

class History_Order_Controller extends Controller
{
    public function DeleteHistori($id)
    {
        $H=new History_Order();
        $H->DeleteHistori($id);
    return redirect()->back()->with('info',"Видалено з Истории покупок");
    }
}
