<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Order;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\Auth;
class CheckoutController extends Controller
{
    public function index()
    {
        $session_Value=session('name_session');
        $user_in_session=User::where('email',$session_Value)->get();
        $temp_ID=0;
        foreach($user_in_session as $i)
        {
            $temp_ID=$i->id;

        }
        $product_id=Order::where('user_id',$temp_ID)->get();
        $helper= new User();



        return view('Checkout.ST_Chekout',['product_id'=>$product_id,
        'favorite_counter'=>$helper->favorite_counter(),
        'order_counter'=>$helper->order_counter(),
        'total'=>$helper->total(),
        'hover_cart'=>$helper->hower_cart(),
        'userCheckout'=>$user_in_session]);
      

    }
  
    public function orderUp()
    {
    $up=new Order();
    $up->update_order();
    return redirect()->route('index_main')->with('info',"Заказ підтверджено");
    }
    
}
