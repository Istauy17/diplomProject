<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AutenteficationController extends Controller
{
    
    public function getregistration()
    {
        $helper= new User();
        return view('Auth.register',
        [
            'favorite_counter'=>$helper->favorite_counter(),
            'order_counter'=>$helper->order_counter(),
            'hover_cart'=>$helper->hower_cart(),
            'total'=>$helper->total(),
            ]);


    } 
    public function postregistration(Request $request)
    {
        $this->validate($request,[
            'email'=>'required|unique:users|email|max:255',
            'password'=>'min:6|required_with:password_confirm|same:password_confirm',
            'password_confirm'=>'min:6',
            'firstname'=>'required|max:100',
            'lastname'=>'required|max:100',
            'phone'=>'required|:10',
            'address'=>'required|max:255',
            'country'=>'required|max:255',
            

        ]);

        User::create([
            'email'=>$request->input('email'),
            'password'=>Hash::make($request->input('password')),
            'role_id'=>2,
            'firstname'=>$request->input('firstname'),
            'lastname'=>$request->input('lastname'),
            'phone'=>$request->input('phone'),
            'address'=>$request->input('address'),
            'country'=>$request->input('country'),

        ]);

        return redirect()->route('index_main')->with('info','Ви успішно зареєструвалися');
       


    } 
    public function getlogin()
    {
        $helper= new User();
        return view('Auth.login',['favorite_counter'=>$helper->favorite_counter(),
        'order_counter'=>$helper->order_counter(),
        'total'=>$helper->total(),
        'hover_cart'=>$helper->hower_cart()]);


    } 
   
    public function postlogin(Request $request)
    {
        
        $this->validate($request, [
            'email'=>'required|max:255',
            'password'=>'required|min:6'
        ]);

        
         
        if(!Auth::attempt($request->only(['email','password'])))
        {
           
            return redirect()->back()->with('info',"Неправильний email або пароль");
            
        }

        $user = User::where('email',$request->input('email'))->get();
        $userId = 0;
        foreach($user as $u)
        {
            $userId = $u->role_id;
        }
        
        if($userId == 1)
        {
            $request->session()->push('admin_session',$request->input('email'));
            return redirect()->route('admin.index');
        }
        else
        {
            $request->session()->push('name_session',$request->input('email'));
        }
       

        return redirect()->route('index_main')->with('info','Ви успішно авторизувались');
        


    } 



    

}
