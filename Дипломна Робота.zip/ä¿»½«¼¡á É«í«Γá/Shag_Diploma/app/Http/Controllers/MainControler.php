<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ImgContent;
use App\Product;
use App\User;

class MainControler extends Controller
{
    public function index()
    {
$img=ImgContent::all();
$cloth=Product::all();
$helper= new User();

$favorite_counter=$helper->favorite_counter();
$order_counter=$helper->order_counter();
$total=$helper->total();
$hover_cart=$helper->hower_cart();
return view('main',compact('img','cloth','favorite_counter','order_counter','total','hover_cart'));



    } 

}
