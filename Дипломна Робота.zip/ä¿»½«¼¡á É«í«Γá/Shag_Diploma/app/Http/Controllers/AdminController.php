<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Collection;
use App\Brand;
use App\History_Order;
use App\User;
use App\Tag;
use App\Role;
use Illuminate\Support\Facades\DB;


class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $userInfo = [];
        $user = User::all();
        $helper= new User();
        $userEm = session('admin_session');
        $userCurrent = User::where('email',$userEm)->get();
        return view('Admin.ST_admin',[
            'favorite_counter'=>$helper->favorite_counter(),
            'order_counter'=>$helper->order_counter(),
            'total'=>$helper->total(),
            'hover_cart'=>$helper->hower_cart(),
            'userCurrent'=>$userCurrent,
            'user'=>$user,
            'userInfo'=>$userInfo
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tempInfo = User::find($id);
        $tempInfo->firstname=$request->get('firstname');
 $tempInfo->lastname=$request->get('lastname');
 $tempInfo->email=$request->get('email');
 $tempInfo->phone=$request->get('phone');
 $tempInfo->address=$request->get('address');
 $tempInfo->country=$request->get('country');
 $tempInfo->postcode=$request->get('postcode');
 $tempInfo->City=$request->get('city');

 $tempInfo->save();
 return redirect()->route('admin.index')->with('info',"Ви успішно редагували данні");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    

    public function getEdit_product_views($id)
    {
        //$cloth=Product::all();
    $cloth = Product::where('id',$id)->get();
    $collection = Collection::all();
    $brand = Brand::all();
    $helper= new User();
    $tag = Tag::all();
   
    $size = DB::select('select * from sizes');
    return view('Admin.Edit_Product',[
    'cloth'=>$cloth,
    'favorite_counter'=>$helper->favorite_counter(),
    'order_counter'=>$helper->order_counter(),
    'total'=>$helper->total(),
    'hover_cart'=>$helper->hower_cart(),
    'brand'=>$brand,
    'collection'=>$collection,
    'tag'=>$tag,
    'size'=>$size]);



    }

    public function  postEdit_product_views(Request $request, $id)
    {
        
        $logo = '';
        
        
        
       
       if($request->input('old_img'))
       {
        $logo = $request->input('old_img');
       }
        if($request->hasFile('img')){
            $fileAvatar = $request->file('img');
            $logo = $fileAvatar->getClientOriginalName();
            $fileAvatar->move(public_path().'/assets/img/products', $logo);
           }
         
        
           

        $product = Product::find($id);
        $product->name = $request->get('name');
        $product->prise = $request->get('prise');
        $product->description = $request->get('description');
        $product->img = $logo;
        $product->brand_id = $request->get('brands');
        $product->tag_id = $request->get('tags');
        $product->collection_id = $request->get('collections');
        $product->size_id = $request->get('sizes');
        $product->save();

        return redirect()->route('Shop')->with('info','Товар успешно обновлен');


    }
    public function  Delete_product_views($id)
    {
        $product = Product::find($id);
        $product->delete();


return redirect()->route('Shop')->with('info','Товар успешно удален');

    }
    public function  getAdd_product_views()
    {
        
        $collection = Collection::all();
        $brand = Brand::all();
        $helper= new User();
        $tag = Tag::all();
       
        $size = DB::select('select * from sizes');
        return view('Admin.Add_Product',[
        'favorite_counter'=>$helper->favorite_counter(),
        'order_counter'=>$helper->order_counter(),
        'total'=>$helper->total(),
        'hover_cart'=>$helper->hower_cart(),
        'brand'=>$brand,
        'collection'=>$collection,
        'tag'=>$tag,
        'size'=>$size]);
    

    }
    public function  postAdd_product_views(Request $request)
    {
        $logo = '';
        if($request->hasFile('img')){
            $fileAvatar = $request->file('img');
            $logo = $fileAvatar->getClientOriginalName();
            $fileAvatar->move(public_path().'/assets/img/products', $logo);
           }
         
           Product::create([
               'name' => $request->input('name'),
               'prise' => $request->input('prise'),
               'size_id' => $request->input('sizes'),
               'description' => $request->input('description'),
               'img' =>$logo,
               'brand_id' => $request->input('brands'),
               'tag_id' => $request->input('tags'),
               'collection_id' => $request->input('collections'),
               
           ]);


        return redirect()->route('Shop')->with('info','Товар успешно добавлен');

    }
    public function  UserInfo($id)
    {
       $userInfo = [];

       if($id)
       {
           $userInfo = History_Order::where('user_id',$id)->get();
       }

       $user = User::all();
       $helper= new User();
       $userEm = session('admin_session');
       $userCurrent = User::where('email',$userEm)->get();
       return view('Admin.ST_admin',[
           'favorite_counter'=>$helper->favorite_counter(),
           'order_counter'=>$helper->order_counter(),
           'total'=>$helper->total(),
           'hover_cart'=>$helper->hower_cart(),
           'userCurrent'=>$userCurrent,
           'user'=>$user,
           'userInfo'=>$userInfo
       ]);


    }


    public function  getEditRole($id)
    {
        $userC=  User::where('id',$id)->get();
        $collection = Collection::all();
        $brand = Brand::all();
        $helper= new User();
        $tag = Tag::all();
        $role = Role::all();
       
        $size = DB::select('select * from sizes');
        return view('Admin.Edit_role',[
        'favorite_counter'=>$helper->favorite_counter(),
        'order_counter'=>$helper->order_counter(),
        'total'=>$helper->total(),
        'hover_cart'=>$helper->hower_cart(),
        'brand'=>$brand,
        'collection'=>$collection,
        'tag'=>$tag,
        'size'=>$size,
        'role'=>$role,
        'userC'=>$userC]);
    

    }

    public function  postEditRole(Request $request,$id)
    {
        
        $user = User::find($id);
        $user->role_id = $request->input('roles');
        $user->save();

        return redirect()->back()->with('info','Роль пользователя изменена');
    

    }

    public function  getStatusOrder($id)
    {
        $userC=  User::where('id',$id)->get();
        $collection = Collection::all();
        $brand = Brand::all();
        $helper= new User();
        $tag = Tag::all();
        $role = Role::all();
        $history = History_Order::where('id',$id)->get();
        $size = DB::select('select * from sizes');
        return view('Admin.StatusOrder',[
        'favorite_counter'=>$helper->favorite_counter(),
        'order_counter'=>$helper->order_counter(),
        'total'=>$helper->total(),
        'hover_cart'=>$helper->hower_cart(),
        'brand'=>$brand,
        'collection'=>$collection,
        'tag'=>$tag,
        'size'=>$size,
        'role'=>$role,
        'userC'=>$userC,
        'history'=>$history]);
    

    }

    public function  postStatusOrder(Request $request,$id)
    {
        
        $history = History_Order::find($id);
        $history->status_order = $request->input('status');
        $history->save();

        return redirect()->back()->with('info','Статус заказа пользователя изменено');
    

    }




}




