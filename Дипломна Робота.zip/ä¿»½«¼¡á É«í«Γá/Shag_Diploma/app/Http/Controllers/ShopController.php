<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Filters\ShopFilter;
use App\Product;
use App\User;
use App\Brand;
use App\Collection;
use App\Tag;

class ShopController extends Controller
{
    
public function index(ShopFilter $request)
    {
//$cloth=Product::all();
$cloth = Product::filter($request)->paginate(6);
$collection = Collection::all();
$brand = Brand::all();
$helper= new User();
$tag = Tag::all();
return view('Shop.ST_Shop',[
'cloth'=>$cloth,
'favorite_counter'=>$helper->favorite_counter(),
'order_counter'=>$helper->order_counter(),
'total'=>$helper->total(),
'hover_cart'=>$helper->hower_cart(),
'brand'=>$brand,
'collection'=>$collection,
'tag'=>$tag]);

    } 
}
