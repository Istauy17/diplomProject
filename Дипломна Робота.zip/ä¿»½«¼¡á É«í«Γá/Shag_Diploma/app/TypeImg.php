<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeImg extends Model
{
    protected $table='type_img';

    protected $fillable = [
        'Name'
    ];
    public function ImgContent()
    {

return $this->hasMany(ImgContent::class,'type_id','id');

    }
}
