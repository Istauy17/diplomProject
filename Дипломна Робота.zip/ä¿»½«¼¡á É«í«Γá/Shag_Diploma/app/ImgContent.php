<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ImgContent extends Model
{
    protected $table='img_content';
    
    protected $fillable = [
        'Name','type_id'
    ];
    public function TypeImg()
    {

return $this->belongsTo(TypeImg::class,'type_id','id');

    }
}
