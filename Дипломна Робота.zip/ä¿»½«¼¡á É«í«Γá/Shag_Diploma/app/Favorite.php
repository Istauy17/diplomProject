<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\ShopingCart;
use App\Product;

class Favorite extends Model
{ 

    protected $fillable = [
        'user_id','product_id'
    ];

    public function Products()
    {

return $this->belongsTo(Product::class,'product_id','id');

    }


    public function Users()
    {

return $this->belongsTo(User::class,'user_id','id');

    }


public function Favorite_out()
{

    $session_Value=session('name_session');
    $user_in_session=User::where('email',$session_Value)->get();
    $temp_ID=0;
    foreach($user_in_session as $i)
    {
        $temp_ID=$i->id;

    }

    $product=$this->where('user_id',$temp_ID)->get();

    return  $product;

}

public function Add_Favorite($id)
{

    $session_Value=session('name_session');
    $user_in_session=User::where('email',$session_Value)->get();
    $temp_ID=0;
    foreach($user_in_session as $i)
    {
        $temp_ID=$i->id;

    } 
$this->create
(
    [
        'user_id'=>$temp_ID,
        'product_id'=>$id

    ]
);

}

public function Delete_Favorite($id)
{
    $order=$this->find($id);
$order->delete();


}

}
