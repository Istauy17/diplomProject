<?php

namespace App;
use App\Filters\QueryFilter;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{  
     protected $fillable = [
    'name','size_id', 'prise', 'img','collection_id', 'description','brand_id','tag_id'
];

public function Orders()
{

return $this->hasMany(Order::class,'product_id','id');

}
public function Favorite()
{

return $this->hasMany(Favorite::class,'product_id','id');

}

public function History_Order()
{

return $this->hasMany(History_Order::class,'product_id','id');

}
public function Tags()
{

return $this->belongsTo(Tag::class,'tag_id','id');

}



public function scopeFilter(Builder $builder, QueryFilter $filter){
    return $filter->apply($builder);
}

}
