
    <!-- Shopping Cart Section Begin -->
    <section class="shopping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th class="p-name">Product Name</th>
                                    <th>Price</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $totalPrise=0;

                            

                            ?> 
                            @foreach( $favorite as $product )
                            <?php
                            $totalPrise+=$product->Products['prise'];

                            

                            ?> 
                                <tr>
                                    <td class="cart-pic first-row"><img style="width:95%; height:10%;" src="assets/img/products/{{$product->Products['img']}}" alt=""></td>
                                    <td class="cart-title first-row">
                                        <h5>{{$product->Products['name']}}</h5>
                                    </td>
                                    <td class="p-price first-row">₴{{$product->Products['prise']}}</td>
                                   
                                   
                                    <td class="close-td first-row"><a onclick="return confirm('Do you really want to delete?')" href="{{route('DeleteFavorite',$product->id)}}"> <i class="ti-close"></i></a></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="cart-buttons">
                                <a href="{{route('Shop')}}" class="primary-btn continue-shop">Continue shopping</a>
                                <a href="{{route('ShopingCart')}}" class="primary-btn up-cart">Update cart</a>
                            </div>
                            <div class="discount-coupon">
                                <h6>Discount Codes</h6>
                                <form action="#" class="coupon-form">
                                    <input type="text" placeholder="Enter your codes">
                                    <button type="submit" class="site-btn coupon-btn">Apply</button>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-4 offset-lg-4">
                            <div class="proceed-checkout">
                                <ul>
                                
                                    <li class="subtotal">Subtotal <span>₴{{$totalPrise}}</span></li>
                                    <li class="cart-total">Total <span>₴{{$totalPrise}}</span></li>
                                </ul>
                                <a href="{{route('Chekout')}}" class="proceed-btn">PROCEED TO CHECK OUT</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shopping Cart Section End -->