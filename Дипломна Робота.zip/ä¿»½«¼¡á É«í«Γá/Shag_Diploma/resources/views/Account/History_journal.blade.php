<section class="shopping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th class="p-name">Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $totalPrise=0;

                            ?> 
                            @foreach($History_Order as $product )
                            <?php
                            $totalPrise+=$product->Products['prise'];
                            ?> 
                           
                                <tr>
                                    <td class="cart-pic first-row"><img src="assets/img/products/{{$product->Products['img']}}" alt=""></td>
                                    <td class="cart-title first-row">
                                        <h5>{{$product->Products['name']}}</h5>
                                    </td>
                                    <td class="p-price first-row">₴{{$product->Products['prise']}}</td>
                                    <td class="qua-col first-row">
                                        <div class="quantity">
                                            <div class="pro-qty">
                                                <input type="text" value="{{$product->quentities}}">
                                            </div>
                                        </div>
                                    </td>
                                    <td class="total-price first-row">₴{{$product->total}}</td>
                                    <td class="close-td first-row"><a onclick="return confirm('Do you really want to delete?')" href="{{route('DeleteHistori',$product->id)}}"> <i class="ti-close"></i></a></td>
                                </tr>
                                
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="cart-buttons">
                                <a href="{{route('Shop')}}" class="primary-btn continue-shop">Continue shopping</a>
                               
                            </div>
                           
                        </div>   
                    </div>
                </div>
            </div>
        </div>
    </section>