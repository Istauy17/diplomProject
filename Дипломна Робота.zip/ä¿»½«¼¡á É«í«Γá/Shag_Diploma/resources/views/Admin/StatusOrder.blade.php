@extends('Structure.main_ST1')
@section('header')
@include('Head_FOOTER_Content.header')
@endsection
@section('content')
@foreach($history as $h)
<form action="{{route('StatusOrder',$h->id)}}" method="POST">
@csrf

<div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" name="status" class="form-control" id="inputEmail4" placeholder="Status Order"  value="{{$h->status_order}}">
    </div>
  
  
 

</div>
<div class="form-group">
 <button type="submit" class="btn btn-primary form-group">Accept</button>
 </div>
  
</form>
@endforeach


@endsection
@section('footer')
@include('Head_FOOTER_Content.footer')
@endsection