@extends('Structure.main_ST1')
@section('header')
@include('Head_FOOTER_Content.header')
@endsection
@section('content')
@foreach($userC as $us)
<form action="{{route('EditRole',$us->id)}}" method="POST">
@csrf

 
  
    <div class="form-group col-md-4">
      <label for="inputState">Role</label>
      <select name="roles" d="inputState" class="form-control">
        <option selected>Choose...</option>
        @foreach($role as $r)
        <option value="{{$r->id}}">{{$r->name}}</option>
        @endforeach
      </select>
    </div>

    
  
  
 
  <button type="submit" class="btn btn-primary">Accept</button>

  
</form>

@endforeach

@endsection
@section('footer')
@include('Head_FOOTER_Content.footer')
@endsection