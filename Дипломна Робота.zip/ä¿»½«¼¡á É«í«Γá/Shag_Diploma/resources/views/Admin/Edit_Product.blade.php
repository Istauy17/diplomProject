@extends('Structure.main_ST1')
@section('header')
@include('Head_FOOTER_Content.header')
@endsection
@section('content')
<?php $oldName = '';?>
@foreach($cloth as $c)
<form action="{{route('EditAdminInfo',$c->id)}}" method="POST" enctype="multipart/form-data">
@csrf
<?php 

    $oldName = $c->img;
?>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Email" name="name" value="{{$c->name}}">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Prise</label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="Password" name="prise" value="{{$c->prise}}">
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Description</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St"  name="description"value="{{$c->description}}">
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Example file input</label>
    <input type="hidden" name="old_img" value="{{$oldName}}">
    <img style="width: 100px;" src="{{asset('assets/img/products/'.$c->img)}}" alt="">
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Example file input</label>
    <input name="img" type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
  
    <div class="form-group col-md-4">
      <label for="inputState">Brand</label>
      <select name="brands" d="inputState" class="form-control">
        <option selected>Choose...</option>
        @foreach($brand as $b)
        <option value="{{$b->id}}">{{$b->name}}</option>
        @endforeach
      </select>
    </div>

    <div class="form-group col-md-4">
      <label for="inputState">Collection</label>
      <select name="collections" id="inputState" class="form-control">
        <option selected>Choose...</option>
        @foreach($collection as $c)
        <option value="{{$c->id}}">{{$c->name}}</option>
        @endforeach
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Size</label>
      <select name="sizes" id="inputState" class="form-control">
        <option selected>Choose...</option>
        @foreach($size as $s)
        <option value="{{$s->id}}">{{$s->Name}}</option>
        @endforeach
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Tag</label>
      <select name="tags" id="inputState" class="form-control">
        <option selected>Choose...</option>
        @foreach($tag as $t)
        <option value="{{$t->id}}">{{$t->name}}</option>
        @endforeach
      </select>
    </div>
  
  
 
  <button type="submit" class="btn btn-primary">Accept</button>

  
</form>
@endforeach



@endsection
@section('footer')
@include('Head_FOOTER_Content.footer')
@endsection