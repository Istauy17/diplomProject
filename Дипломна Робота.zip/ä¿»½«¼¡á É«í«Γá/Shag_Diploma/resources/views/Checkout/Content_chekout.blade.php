   <!-- Shopping Cart Section Begin -->
   <section class="checkout-section spad">
        <div class="container">
            <form action="{{route('OrderUP')}}" method="POST" class="checkout-form">
            @csrf
                <div class="row">
                    <div class="col-lg-6">
                        <h4>Biiling Details</h4>
                        <div class="row">
                            @foreach($userCheckout as $item)
                            <div class="col-lg-6">
                                <label for="fir">First Name<span>*</span></label>
                                <input type="text" id="fir" value="{{$item->firstname}}">
                            </div>
                            <div class="col-lg-6">
                                <label for="last">Last Name<span>*</span></label>
                                <input type="text" id="last" value="{{$item->lastname}}">
                            </div>
                            <div class="col-lg-12">
                                <label for="cun">Country<span>*</span></label>
                                <input type="text" id="cun" value="{{$item->country}}">
                            </div>
                            <div class="col-lg-12">
                                <label for="street">Street Address<span>*</span></label>
                                <input type="text" id="street" class="street-first" value="{{$item->address}}">
                            </div>
                            <div class="col-lg-12">
                                <label for="zip">Postcode / ZIP (optional)</label>
                                <input type="text" id="zip" value="{{$item->postcode}}">
                            </div>
                            <div class="col-lg-12">
                                <label for="town">Town / City<span>*</span></label>
                                <input type="text" id="town" value="{{$item->City}}">
                            </div>
                            <div class="col-lg-6">
                                <label for="email">Email Address<span>*</span></label>
                                <input type="text" id="email" value="{{$item->email}}">
                            </div>
                            <div class="col-lg-6">
                                <label for="phone">Phone<span>*</span></label>
                                <input type="text" id="phone" value="{{$item->phone}}">
                            </div>
                            @endforeach
                            <div class="col-lg-12">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="place-order">
                            <h4>Your Order</h4>
                            <div class="order-total">
                                <ul class="order-table">
                                    <li>Product <span>Total</span></li>
                                    <?php
                            $totalPrise=0;
                            ?> 
                                    @foreach( $product_id as $product )

                                    <?php
                            $totalPrise+=$product->Products['prise'];
                            ?> 
                                    <li class="fw-normal">{{$product->Products['name']}} x {{$product->quentities}} <span>₴{{$product->Products['prise']}}</span></li>
                                    @endforeach
                                    <li class="fw-normal">Subtotal <span>₴{{$totalPrise}}</span></li>
                                    <li class="total-price">Total <span>₴{{$totalPrise}}</span></li>
                                </ul>
                               
                                <div class="order-btn">
                                 
                                   <button type="submit" class="site-btn place-btn" >Place Order</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!-- Shopping Cart Section End -->
