<!-- Hero Section Begin -->
<section class="hero-section">
        <div class="hero-items owl-carousel">
        @foreach($img as $ImgMainBaner)
                    @if($ImgMainBaner->TypeImg['Name'] == 'MainBaner' )
            <div class="single-hero-items set-bg" data-setbg="assets/img/{{$ImgMainBaner['Name']}}">
                <div class="container">
                    <div class="row">
                   

                        <div class="col-lg-5">
                            <span>Bag,kids</span>
                            <h1>Black friday</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore</p>
                            <a href="{{route('Shop')}}" class="primary-btn">Shop Now</a>
                        </div>
                   
                    </div>
                    <div class="off-card">
                        <h2>Sale <span>50%</span></h2>
                    </div>
                   
                </div>
            </div>
            @endif
         @endforeach
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Banner Section Begin -->
    <div class="banner-section spad">
        <div class="container-fluid">
            <div class="row">
            @foreach($img as $ImgMainBaner)
                    @if($ImgMainBaner->TypeImg['Name'] == 'Men' )
                <div class="col-lg-4">
                    <div class="single-banner">
                        <img src="assets/img/{{$ImgMainBaner['Name']}}" alt="">
                        <div class="inner-text">
                            <h4><a style="color:goldenrod" href="http://public/Shop?collection_id=1">Men’s</a></h4>
                        </div>
                    </div>
                </div>
                @endif
         @endforeach
         @foreach($img as $ImgMainBaner)
                    @if($ImgMainBaner->TypeImg['Name'] == 'Women' )
                <div class="col-lg-4">
                    <div class="single-banner">
                        <img src="assets/img/{{$ImgMainBaner['Name']}}" alt="">
                        <div class="inner-text">
                            <h4><a style="color:goldenrod" href="http://public/Shop?collection_id=2">Women’s</a></h4>
                        </div>
                    </div>
                </div>
                @endif
         @endforeach
                @foreach($img as $ImgMainBaner)
                    @if($ImgMainBaner->TypeImg['Name'] == 'Kids' )
                <div class="col-lg-4">
                    <div class="single-banner">
                        <img src="assets/img/{{$ImgMainBaner['Name']}}" alt="">
                        <div class="inner-text">
                            <h4><a style="color:goldenrod" href="http://public/Shop?collection_id=3">Kid’s</a></h4>
                        </div>
                    </div>
                </div>
                @endif
         @endforeach
            </div>
        </div>
    </div>
    <!-- Banner Section End -->

    <!-- Women Banner Section Begin -->
    <section class="women-banner spad">
        <div class="container-fluid">
            <div class="row">
            @foreach($img as $ImgMainBaner)
                    @if($ImgMainBaner->TypeImg['Name'] == 'WomenScrol' )
                <div class="col-lg-3">
                    <div class="product-large set-bg" data-setbg="assets/img/products/{{$ImgMainBaner['Name']}}">
                        <h2>Women’s</h2>
                       
                    </div>
                </div>
                @endif
         @endforeach
                <div class="col-lg-8 offset-lg-1">
                <div class="filter-control">
                        
                </div>           
                    <div  class="product-slider owl-carousel">
                    @foreach($cloth as $item)
                    @if($item->collection_id == '2' )
                        <div   class="product-item">
                            <div class="pi-pic">
                                <img style="width: 250px; height: 350px;" src="assets/img/products/{{$item['img']}}" alt="">                              
                                <div class="icon">
                                <a href="{{route('AddFavorite',$item->id)}}"><i class="icon_heart_alt"></i></a>
                                </div>
                                <ul>
                                    <li class="w-icon active"><a href="{{route('AddToShopingCart',$item->id)}}"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul>
                            </div>
                            <div class="pi-text">
                                <div class="catagory-name">{{$item->Tags['name']}}</div>
                                <a href="#">
                                    <h5>{{$item->name}}</h5>
                                </a>
                                <div class="product-price">
                                ₴{{$item->prise}}
                                </div>
                            </div>
                        </div>
                        @endif
                    @endforeach
                    </div>
                   
                </div>
            </div>
        </div>
    </section>
    <!-- Women Banner Section End -->

    <!-- Deal Of The Week Section Begin-->
    @foreach($img as $ImgMainBaner)
                    @if($ImgMainBaner->TypeImg['Name'] == 'DealOfTheWeek' )
    <section class="deal-of-week set-bg spad" data-setbg="assets/img/{{$ImgMainBaner['Name']}}">
    @endif
         @endforeach
        <div class="container">
            <div class="col-lg-6 text-center">
                <div class="section-title">
                    <h2>Deal Of The Week</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed<br /> do ipsum dolor sit amet,
                        consectetur adipisicing elit </p>
                    <div class="product-price">
                    ₴350.00
                        <span>/ HanBag</span>
                    </div>
                </div>
                <div class="countdown-timer" id="countdown">
                    <div class="cd-item">
                        <span>56</span>
                        <p>Days</p>
                    </div>
                    <div class="cd-item">
                        <span>12</span>
                        <p>Hrs</p>
                    </div>
                    <div class="cd-item">
                        <span>40</span>
                        <p>Mins</p>
                    </div>
                    <div class="cd-item">
                        <span>52</span>
                        <p>Secs</p>
                    </div>
                </div>
                <a href="{{route('Shop')}}" class="primary-btn">Shop Now</a>
            </div>
        </div>
    </section>
    <!-- Deal Of The Week Section End -->

    <!-- Man Banner Section Begin -->
    <section class="man-banner spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <div class="filter-control">
                        
                    </div>
                    <div class="product-slider owl-carousel">
                    @foreach($cloth as $item)
                    @if($item->collection_id == '1' )
                        <div class="product-item">
                            <div class="pi-pic">
                                <img style="width: 250px; height: 350px;" src="assets/img/products/{{$item['img']}}" alt="">
                                <div class="icon">
                                    <a href="{{route('AddFavorite',$item->id)}}"><i class="icon_heart_alt"></i></a>
                                </div>
                                <ul>
                                    <li class="w-icon active"><a href="{{route('AddToShopingCart',$item->id)}}"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul>
                            </div>
                            <div class="pi-text">
                                <div class="catagory-name">{{$item->Tags['name']}}</div>
                                <a href="#">
                                    <h5>{{$item->name}}</h5>
                                </a>
                                <div class="product-price">
                                ₴{{$item->prise}}
                                </div>
                            </div>
                        </div>
                        @endif
                    @endforeach

                    </div>
                </div>

                @foreach($img as $ImgMainBaner)
                    @if($ImgMainBaner->TypeImg['Name'] == 'MenScrol' )
                <div class="col-lg-3 offset-lg-1">
                    <div class="product-large set-bg m-large" data-setbg="assets/img/products/{{$ImgMainBaner['Name']}}">
                        <h2>Men’s</h2>
            
                    </div>
                </div>
                @endif
         @endforeach
            </div>
        </div>
    </section>
    <!-- Man Banner Section End -->

    

   

