  <!-- Header Section Begin -->
        <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-1 col-md-1">
                        <div class="logo">
                            <a href="{{route('index_main')}}">
                                <img src="{{asset('assets/img/logo.png')}}" alt="">
                            </a>
                        </div>
                    </div>
                   
                    <div class="col-lg-7 col-md-6">
                        <div class="advanced-search">
                            <!-- <button type="button" class="category-btn">All Categories</button> -->
                           
                            <div class="input-group">
                            <form action="{{route('Shop')}}" method="GET">
                                <input name="search_field" type="text" placeholder="What do you need?">
                                <button type="submit"><i class="ti-search"></i></button>
                                </form>
                            </div>
                           
                        </div>
                    </div>
                    
                    <div class="col-lg-1 text-right col-md-1">
                       
                   
                      
                </div>
                    
                    <div class="col-lg-3 text-right col-md-3">
                   
                        <ul class="nav-right">
                            <li class="heart-icon">
                                <a href="{{route('Favorite')}}">
                                    <i class="icon_heart_alt"></i>
                                   
                                    <span>{{$favorite_counter}}</span>
                                    
                                </a>
                            </li>
                            <li class="cart-icon">
                                <a href="{{route('ShopingCart')}}">
                                    <i class="icon_bag_alt"></i>
                                
                                    <span>{{$order_counter}}</span>
                            
                                </a>
                            
                                <div class="cart-hover">
                                <?php
                            $totalPrise=0;
                            ?> 
                            @foreach( $hover_cart as $product )
                            <?php
                            $totalPrise+=$product->Products['prise'];
                            ?> 
                                    <div class="select-items">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td class="si-pic"><img src="assets/img/products/{{$product->Products['img']}}" alt=""></td>
                                                    <td class="si-text">
                                                        <div class="product-selected">
                                                            <p>₴{{$product->Products['prise']}}x {{$product->quentities}}</p>
                                                            <h6>Kabino Bedside Table</h6>
                                                        </div>
                                                    </td>
                                                    <td class="si-close">
                                                        <i class="ti-close"></i>
                                                    </td>
                                                </tr>
                                    
                                            </tbody>
                                        </table>
                                    </div>
                                    @endforeach 
                                    <div class="select-total">
                                        <span>total:</span>
                                        <h5>₴{{$totalPrise}}</h5>
                                    </div>
                                   
                                    <div class="select-button">
                                        <a href="{{route('ShopingCart')}}" class="primary-btn view-card">VIEW CARD</a>
                                        <a href="{{route('Chekout')}}" class="primary-btn checkout-btn">CHECK OUT</a>
                                    </div>
                                </div> 
                                
                            </li>
                            <li class="cart-price">₴{{$total}} </li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="nav-item">
            <div class="container">
                <div class="nav-depart">
        
                    
                </div>
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li class="active"><a href="{{route('index_main')}}">Home</a></li>
                        <li><a href="{{route('Shop')}}">Shop</a></li>
                        <li><a href="#">Collection</a>
                            <ul class="dropdown">
                                <li><a href="http://public/Shop?collection_id=1">Men's</a></li>
                                <li><a href="http://public/Shop?collection_id=2">Women's</a></li>
                                <li><a href="http://public/Shop?collection_id=3">Kid's</a></li>
                            </ul>
                        </li>
                        @if(session('admin_session'))
                        <li><a href="{{route('admin.index')}}">Admin</a></li>
                     
                        @endif
                        <li>
                        
                        @if(session('admin_session'))
                        <a class="logo"  href="{{route('admin.index')}}"  class="login-panel"><i style="font-size:18px ;" class="fas fa-user-circle"> </i>Account</a>
                        @else
                        <a class="logo"  href="{{route('Account')}}"  class="login-panel"><i  style="font-size:18px ;" class="fas fa-user-circle"> </i>Account</a>
                        @endif

                        </li>
                        @if(Auth::check())
                        <li><li> <a href="{{route('out')}}" class="login-panel"><i class="fa fa-user"></i>Logout</a></li>
                        @else
                        <li><li> <a href="{{route('login')}}" class="login-panel"><i class="fa fa-user"></i>Login / Register</a></li>
                        @endif
                        
                        </li>
                        
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End -->