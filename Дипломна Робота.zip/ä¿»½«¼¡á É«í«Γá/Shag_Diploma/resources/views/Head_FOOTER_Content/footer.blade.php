   <!-- Footer Section Begin -->
   <footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="footer-left">
                        <div class="footer-logo">
                            <a href="#"><img src="img/footer-logo.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: Khmelnitsky</li>
                            <li>Phone: +380980393886</li>
                            <li>Email: istauy1712@gmail.com</li>
                        </ul>
                        <div class="footer-social">
                            <a href="https://www.facebook.com/kolia.vlasiuk.3/"><i class="fa fa-facebook"></i></a>
                            <a href="https://www.instagram.com/eterna1_sin_asmodeus/"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1">
                    <div class="footer-widget">
                        <h5>Information</h5>
                        <ul>
                            <li><a href="{{route('index_main')}}">Home</a></li>
                            <li><a href="{{route('Shop')}}">Shop</a></li>
                            <li><a href="{{route('login')}}">Login/Register</a></li>
                            
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="footer-widget">
                        <h5>My Account</h5>
                        <ul>

                        @if(session('admin_session'))
                        <li><a href="{{route('admin.index')}}">My Account</a></li>
                        @else
                        <li><a href="{{route('Account')}}">My Account</a></li>
                        @endif
                            
                            <li><a href="{{route('Favorite')}}">Favorites</a></li>
                            <li><a href="{{route('ShopingCart')}}">Shopping Cart</a></li>
                            
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                   
                </div>
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
                        
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://github.com/Istauy1712" target="_blank">Nikolai Vlasiuk</a>

                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->