
let div=document.getElementsByClassName('edit');

function edit ()
{
    for(let i=0;i<div.length;i++)
    {

        div[i].style.display="block";

    }



}


