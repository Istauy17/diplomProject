<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','MainControler@index')->name('index_main');
Route::get('/register','AutenteficationController@getregistration')->name('register');
Route::post('/register','AutenteficationController@postregistration');
Route::get('/login','AutenteficationController@getlogin')->name('login');
Route::post('/login','AutenteficationController@postlogin');
Route::get('/Shop','ShopController@index')->name('Shop');
Route::get('/Chekout','CheckoutController@index')->name('Chekout');
Route::get('/ShopingCart','ShopCartController@index')->name('ShopingCart');
Route::get('/AddToShopingCart/{id}','ShopCartController@create_cart')->name('AddToShopingCart');
Route::get('/DeleteToShopingCart/{id}','ShopCartController@delete')->name('DeleteToShopingCart');
Route::get('/Out','AccountController@out')->name('out');
Route::get('/Account','AccountController@index')->name('Account');
Route::post('/EditInfo','AccountController@postEditInfo')->name('EditInfo');
Route::get('/Favorite','Favorite_Controller@index')->name('Favorite');
Route::get('/AddFavorite/{id}','Favorite_Controller@AddFavorite')->name('AddFavorite');
Route::get('/DeleteFavorite/{id}','Favorite_Controller@DeleteFavorite')->name('DeleteFavorite');
Route::post('/OrderUP','CheckoutController@orderUp')->name('OrderUP');
Route::get('/DeleteHistori/{id}','History_Order_Controller@DeleteHistori')->name('DeleteHistori');
Route::get('/Description/{id}','Description_Controller@index')->name('Description');
Route::resource('admin','AdminController');
Route::get('/EditAdminInfo/{id}','AdminController@getEdit_product_views')->name('EditAdminInfo');
Route::post('/EditAdminInfo/{id}','AdminController@postEdit_product_views');
Route::get('/DeleteAdminInfo/{id}','AdminController@Delete_product_views')->name('DeleteAdminInfo');
Route::get('/AddAdminInfo','AdminController@getAdd_product_views')->name('AddAdminInfo');
Route::post('/AddAdminInfo','AdminController@postAdd_product_views');
Route::get('/InfoAdminProduct/{id}','AdminController@UserInfo')->name('InfoAdminProduct');
Route::get('/EditRole/{id}','AdminController@getEditRole')->name('EditRole');
Route::post('/EditRole/{id}','AdminController@postEditRole');
Route::post('/UpdateCart','ShopCartController@updateCart')->name('updateCart');

Route::get('/StatusOrder/{id}','AdminController@getStatusOrder')->name('StatusOrder');
Route::post('/StatusOrder/{id}','AdminController@postStatusOrder');

