<?php $__env->startSection('header'); ?>
<?php echo $__env->make('Head_FOOTER_Content.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<form action="<?php echo e(route('AddAdminInfo')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Name" name="name" >
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Prise</label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="Price" name="prise" >
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Description</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="Description"  name="description">
  </div>
  <div class="form-group">
    <label for="exampleFormControlFile1">Example file input</label>
    <input name="img" type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
  
    <div class="form-group col-md-4">
      <label for="inputState">Brand</label>
      <select name="brands" d="inputState" class="form-control">
        <option selected>Choose...</option>
        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($b->id); ?>"><?php echo e($b->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group col-md-4">
      <label for="inputState">Collection</label>
      <select name="collections" id="inputState" class="form-control">
        <option selected>Choose...</option>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Size</label>
      <select name="sizes" id="inputState" class="form-control">
        <option selected>Choose...</option>
        <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($s->id); ?>"><?php echo e($s->Name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Tag</label>
      <select name="tags" id="inputState" class="form-control">
        <option selected>Choose...</option>
        <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($t->id); ?>"><?php echo e($t->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  
  
 
  <button type="submit" class="btn btn-primary">Accept</button>

  
</form>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('Head_FOOTER_Content.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Structure.main_ST1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Admin/Add_Product.blade.php ENDPATH**/ ?>