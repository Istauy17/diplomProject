
    <!-- Shopping Cart Section Begin -->
    <section class="shopping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th class="p-name">Product Name</th>
                                    <th>Price</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $totalPrise=0;

                            

                            ?> 
                            <?php $__currentLoopData = $favorite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $totalPrise+=$product->Products['prise'];

                            

                            ?> 
                                <tr>
                                    <td class="cart-pic first-row"><img  src="assets/img/products/<?php echo e($product->Products['img']); ?>" alt=""></td>
                                    <td class="cart-title first-row">
                                        <h5><?php echo e($product->Products['name']); ?></h5>
                                    </td>
                                    <td class="p-price first-row">₴<?php echo e($product->Products['prise']); ?></td>
                                   
                                   
                                    <td class="close-td first-row"><a onclick="return confirm('Do you really want to delete?')" href="<?php echo e(route('DeleteFavorite',$product->id)); ?>"> <i class="ti-close"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="cart-buttons">
                                <a href="<?php echo e(route('Shop')); ?>" class="primary-btn continue-shop">Continue shopping</a>
                                <a href="<?php echo e(route('Favorite')); ?>" class="primary-btn up-cart">Update cart</a>
                            </div>
                            
                        </div>
                        <div class="col-lg-4 offset-lg-4">
                            <div class="proceed-checkout">
                                <ul>
                                
                                    <li class="subtotal">Subtotal <span>₴<?php echo e($totalPrise); ?></span></li>
                                    <li class="cart-total">Total <span>₴<?php echo e($totalPrise); ?></span></li>
                                </ul>
                                <a href="<?php echo e(route('Chekout')); ?>" class="proceed-btn">PROCEED TO CHECK OUT</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shopping Cart Section End --><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Favorite/Favorite_content.blade.php ENDPATH**/ ?>