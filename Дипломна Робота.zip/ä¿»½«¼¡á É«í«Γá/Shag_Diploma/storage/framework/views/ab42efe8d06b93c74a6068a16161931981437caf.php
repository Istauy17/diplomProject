   <!-- Shopping Cart Section Begin -->
   <section class="checkout-section spad">
        <div class="container">
            <form action="<?php echo e(route('OrderUP')); ?>" method="POST" class="checkout-form">
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-6">
                        <h4>Biiling Details</h4>
                        <div class="row">
                            <?php $__currentLoopData = $userCheckout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6">
                                <label for="fir">First Name<span>*</span></label>
                                <input type="text" id="fir" value="<?php echo e($item->firstname); ?>">
                            </div>
                            <div class="col-lg-6">
                                <label for="last">Last Name<span>*</span></label>
                                <input type="text" id="last" value="<?php echo e($item->lastname); ?>">
                            </div>
                            <div class="col-lg-12">
                                <label for="cun">Country<span>*</span></label>
                                <input type="text" id="cun" value="<?php echo e($item->country); ?>">
                            </div>
                            <div class="col-lg-12">
                                <label for="street">Street Address<span>*</span></label>
                                <input type="text" id="street" class="street-first" value="<?php echo e($item->address); ?>">
                            </div>
                            <div class="col-lg-12">
                                <label for="zip">Postcode / ZIP (optional)</label>
                                <input type="text" id="zip" value="<?php echo e($item->postcode); ?>">
                            </div>
                            <div class="col-lg-12">
                                <label for="town">Town / City<span>*</span></label>
                                <input type="text" id="town" value="<?php echo e($item->City); ?>">
                            </div>
                            <div class="col-lg-6">
                                <label for="email">Email Address<span>*</span></label>
                                <input type="text" id="email" value="<?php echo e($item->email); ?>">
                            </div>
                            <div class="col-lg-6">
                                <label for="phone">Phone<span>*</span></label>
                                <input type="text" id="phone" value="<?php echo e($item->phone); ?>">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-12">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="place-order">
                            <h4>Your Order</h4>
                            <div class="order-total">
                                <ul class="order-table">
                                    <li>Product <span>Total</span></li>
                                    <?php
                            $totalPrise=0;
                            ?> 
                                    <?php $__currentLoopData = $product_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php
                            $totalPrise+=$product->Products['prise'];
                            ?> 
                                    <li class="fw-normal"><?php echo e($product->Products['name']); ?> x <?php echo e($product->quentities); ?> <span>₴<?php echo e($product->Products['prise']); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <li class="fw-normal">Subtotal <span>₴<?php echo e($totalPrise); ?></span></li>
                                    <li class="total-price">Total <span>₴<?php echo e($totalPrise); ?></span></li>
                                </ul>
                               
                                <div class="order-btn">
                                 
                                   <button type="submit" class="site-btn place-btn" >Place Order</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!-- Shopping Cart Section End -->
<?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Checkout/Content_chekout.blade.php ENDPATH**/ ?>