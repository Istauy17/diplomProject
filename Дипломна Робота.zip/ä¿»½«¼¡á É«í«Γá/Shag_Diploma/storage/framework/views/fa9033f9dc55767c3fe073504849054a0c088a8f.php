<section class="shopping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th class="p-name">Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $totalPrise=0;

                            ?> 
                            <?php $__currentLoopData = $History_Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $totalPrise+=$product->Products['prise'];
                            ?> 
                           
                                <tr>
                                    <td class="cart-pic first-row"><img src="assets/img/products/<?php echo e($product->Products['img']); ?>" alt=""></td>
                                    <td class="cart-title first-row">
                                        <h5><?php echo e($product->Products['name']); ?></h5>
                                    </td>
                                    <td class="p-price first-row">₴<?php echo e($product->Products['prise']); ?></td>
                                    <td class="qua-col first-row">
                                        <div class="quantity">
                                            <div class="pro-qty">
                                                <input type="text" value="<?php echo e($product->quentities); ?>">
                                            </div>
                                        </div>
                                    </td>
                                    <td class="total-price first-row">₴<?php echo e($product->total); ?></td>
                                    <td class="close-td first-row"><a onclick="return confirm('Do you really want to delete?')" href="<?php echo e(route('DeleteHistori',$product->id)); ?>"> <i class="ti-close"></i></a></td>
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="cart-buttons">
                                <a href="<?php echo e(route('Shop')); ?>" class="primary-btn continue-shop">Continue shopping</a>
                               
                            </div>
                           
                        </div>   
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Account/History_journal.blade.php ENDPATH**/ ?>