 <!-- Breadcrumb Section Begin -->
 <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>Register</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Form Section Begin -->

    <!-- Register Section Begin -->
<div class="register-login-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="register-form">
                        <h2>Register</h2>
                        <form action="<?php echo e(route('register')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                            <div class="group-input">
                                <label for="Email address">Email address *</label>
                                <input type="text" id="Email address" name="email">
                            </div>
                            <div class="group-input">
                                <label for="Firstname">Firstname *</label>
                                <input type="text" id="Firstname" name="firstname">
                            </div>
                            <div class="group-input">
                                <label for="Lastname">Lastname *</label>
                                <input type="text" id="Lastname" name="lastname">
                            </div>
                            <div class="group-input">
                                <label for="Phone_number">Phone number *</label>
                                <input type="tel" id="Phone_number"name="phone">
                            </div>
                            <div class="group-input">
                                <label for="Adress">Adress *</label>
                                <input type="text" id="Adress"name="address">
                            </div>
                            <div class="group-input">
                                <label for="Country">Country *</label>
                                <input type="text" id="Country"name="country">
                            </div>
                            <div class="group-input">
                                <label for="pass">Password *</label>
                                <input type="text" id="pass"name="password">
                            </div>
                            <div class="group-input">
                                <label for="con-pass">Confirm Password *</label>
                                <input type="text" id="con-pass"name="password_confirm">
                            </div>
                            <button type="submit" class="site-btn register-btn">REGISTER</button>
                        </form>
                        <div class="switch-login">
                            <a href="<?php echo e(route('login')); ?>" class="or-login">Or Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Register Form Section End -->
    <?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Auth/ST_login_register/register_content.blade.php ENDPATH**/ ?>