
    <!-- Product Shop Section Begin -->
    <section class="product-shop spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-8 order-2 order-lg-1 produts-sidebar-filter">
               
                <!-- <button type="submit" style=" margin:10px;  color :blue " class="filter-btn"></button> -->
                <?php if(session('admin_session')): ?>
                <button type="submit" class="btn btn-primary"><a style="margin:10px; color:crimson;" href="<?php echo e(route('AddAdminInfo')); ?>" class="filter-btn">Add Product</a></button> 
                <?php endif; ?>
                <form action="<?php echo e(route('Shop')); ?>" method="GET">
               
                    <div class="filter-widget">
                        <h4 class="fw-title">Categories</h4>
                        <!-- <ul class="filter-catagories"> -->
                        <div class="fw-brand-check">
                            <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bc-item">
                            <label>
                                    <?php echo e($c->name); ?>

                                    <input type="checkbox"  name="collection_id" value="<?php echo e($c->id); ?>">
                                    <span class="checkmark"></span>
                                </label></br>
                        </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <!-- </ul> -->
                    </div>
                    <div class="filter-widget">
                        <h4 class="fw-title">Brand</h4>
                        <div class="fw-brand-check">
                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bc-item">
                              
                                <label>
                                    <?php echo e($b->name); ?>

                                    <input type="checkbox"  name="brand_id" value="<?php echo e($b->id); ?>">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="filter-widget">
                        <h4 class="fw-title">Price</h4>
                        <div class="filter-range-wrap">
                            <div class="range-slider">
                                <div class="price-input">
                                    <input name="price_from" type="text" id="minamount">
                                    <input name="price_to" type="text" id="maxamount">
                                </div>
                            </div>
                            <div class="price-range ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                            data-min="0" data-max="100000">
                                <div class="ui-slider-range ui-corner-all ui-widget-header"></div>
                                <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                            </div>
                        </div>
                  
                    </div>
                    
                    <div class="filter-widget">
                        <h4 class="fw-title">Tags</h4>
                        <div class="fw-brand-check">
                            <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bc-item">
                            <label>
                                    <?php echo e($c->name); ?>

                                    <input type="checkbox"  name="tag_id" value="<?php echo e($c->id); ?>">
                                    <span class="checkmark"></span>
                                </label></br>
                        </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Accept</button>
                </div>
               
                </form>
                <div class="col-lg-9 order-1 order-lg-2">
                    <div class="product-show-option">
                        <div class="row">
                            <div class="col-lg-7 col-md-7">
                                <div class="select-option">
                                    
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="product-list" >
                        <div class="row">
                        <?php $__currentLoopData = $cloth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-sm-6">
                                <div class="product-item">
                                    <div style="width: 250px; height: 300px;" class="pi-pic">
                                        <img src="assets/img/products/<?php echo e($item->img); ?>" alt="">
                                       
                                        <div class="icon">
                                            <a href="<?php echo e(route('AddFavorite',$item->id)); ?>">
                                                 <i class="icon_heart_alt"></i>
                                            </a>
                                        </div>
                                        <ul>
                                            <li class="w-icon active"><a href="<?php echo e(route('AddToShopingCart',$item->id)); ?>"><i class="icon_bag_alt"></i></a></li>
                                            <li  class="quick-view"><a href="<?php echo e(route('Description',['id'=>$item->id])); ?>">+ Quick View</a></li>
                                        
                                        </ul>
                                    </div>
                                    <div class="pi-text">
                                        <div class="catagory-name"><?php echo e($item->Tags['name']); ?></div>
                                        <a href="#">
                                            <h5><?php echo e($item->name); ?></h5>
                                        </a>
                                        <div class="product-price">
                                        ₴<?php echo e($item->prise); ?>

                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php echo e($cloth->links()); ?>

                    </div>
                   
                </div>
            </div>
        </div>
    </section>
    <!-- Product Shop Section End -->
<?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Shop/Content_Shop.blade.php ENDPATH**/ ?>