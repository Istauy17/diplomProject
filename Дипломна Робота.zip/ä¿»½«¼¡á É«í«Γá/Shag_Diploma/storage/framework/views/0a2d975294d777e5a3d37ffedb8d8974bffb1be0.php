<?php if(Session::has('info')): ?>
    <div class="alert alert-primary mt-2" role="alert">
    <?php echo e(Session::get('info')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Head_FOOTER_Content/alerts.blade.php ENDPATH**/ ?>