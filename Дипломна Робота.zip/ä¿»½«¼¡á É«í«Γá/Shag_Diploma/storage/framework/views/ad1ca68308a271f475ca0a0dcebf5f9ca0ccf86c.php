 <?php if(session('admin_session')): ?>
 <!-- Faq Section Begin -->
 <div class="faq-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="faq-accordin">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-heading active">
                                    <a class="active" data-toggle="collapse" data-target="#collapseOne">
                                        Personal Details
                                    </a>
                                </div>
                                <div id="collapseOne" class="collapse show" data-parent="#accordionExample">
                                    <section class="checkout-section spad">
                                        <div class="container">
                                        <?php $__currentLoopData = $userCurrent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <form action="<?php echo e(route('admin.update',$u->id)); ?>" method="POST" class="checkout-form">
                                                                                                    
                                            
                                             <?php echo csrf_field(); ?>      
                                             <?php echo method_field('PUT'); ?>
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <h4>Personal Details</h4>
                                                         <div class="row">
                                                                                                             
                                                            <div class="col-lg-6">
                                                                <label for="fir">First Name<span>: <?php echo e($u->firstname); ?></span></label>
                                                            <div style="display:none" class="edit" ><input type="text" value="<?php echo e($u->firstname); ?>" id="fir" name="firstname" required ></div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label for="last">Last Name<span>: <?php echo e($u->lastname); ?></span></label>
                                                                <input type="text"style="display:none" class="edit"value="<?php echo e($u->lastname); ?>" id="last" name="lastname"required>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="cun">Country<span>: <?php echo e($u->country); ?> </span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($u->country); ?>" id="cun" name="country"required>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="street">Street Address<span>:<?php echo e($u->address); ?> </span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($u->address); ?>" id="street"name="address"required class="street-first">
                                                              
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="zip">Postcode / ZIP<span>: <?php echo e($u->postcode); ?> </span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($u->postcode); ?>" id="zip " name="postcode"required>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="town">Town / City<span>: <?php echo e($u->City); ?> </span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($u->City); ?> " id="town" name="city"required>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label for="email">Email Address<span>: <?php echo e($u->email); ?> </span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($u->email); ?>" id="email" name="email"required>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label for="phone">Phone<span>: <?php echo e($u->phone); ?><br> </span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($u->phone); ?>" id="phone" name="phone"required>
                                                            </div>   
                                                                
                                                         
                                                        <div style="margin-left:20px;" class="order-btn">
                                                            <button type="submit"  class="site-btn place-btn">Save</button>
                                                           
                                                        </div>
                                                            
                                                           
                                                        </div>

                                                       
                                                       
                                                    </div>
                                                </div>
                                              
                                            </form>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div  style="margin-left:5px; margin-top:20px ;"class="order-btn">
                                                            <button id="edit_button" onclick="edit()" class="site-btn place-btn">Edit</button>
                                             </div>
                                        </div>
                                    </section>
                                </div>  
                            </div>
                         
                            <div class="card">
                                <div class="card-heading">
                                    <a data-toggle="collapse" data-target="#collapseTwo">
                                        Users
                                    </a>
                                </div>
                                <div id="collapseTwo" class="collapse" data-parent="#accordionExample">
                                    <div class="card-body">
                                       
                                    <section class="shopping-cart spad">


        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead style="width: 100%;">
                                <tr >
                                    <th>Name</th>
                                    <th class="p-name">Last Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Country</th>
                                    <th>postcode</th>
                                    <th>City</th>
                                    <th colspan="4">Operations</th>
                                  

                                    
                                </tr>
                            </thead>
                            <tbody>
                          
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                                <tr>
                                    <td class="cart-pic first-row"><?php echo e($u->firstname); ?></td>
                                    <td class="cart-title first-row">
                                        <?php echo e($u->lastname); ?>

                                    </td>
                                    <td class="p-price first-row"><?php echo e($u->phone); ?></td>
                                    <td class="qua-col first-row">
                                    <?php echo e($u->email); ?>

                                    </td>
                                    <td class="total-price first-row"><?php echo e($u->Roles['name']); ?></td>
                                    <td class="total-price first-row"><?php echo e($u->country); ?></td>
                                    <td class="total-price first-row"><?php echo e($u->postcode); ?></td>
                                    <td class="total-price first-row"><?php echo e($u->City); ?></td>
                                    <td class="close-td first-row"><a onclick="return confirm('Do you really want to delete?')" href="#"><i class="fas fa-trash"></i></a></td>
                                    <td class="close-td first-row"><a  href="<?php echo e(route('EditRole',$u->id)); ?>"><i class="fas fa-user-edit"></i></a></td>
                                    <td class="close-td first-row"><a  href="<?php echo e(route('InfoAdminProduct',$u->id)); ?>"><i class="fas fa-info-circle"></i></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>






                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-heading">
                                    <a data-toggle="collapse" data-target="#collapseThree">
                                      Users Orders
                                    </a>
                                </div>
                                <div id="collapseThree" class="collapse" data-parent="#accordionExample">
                                    <div class="card-body">
                                    <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead>
                               
                                <tr>
                                    <th>Image</th>
                                    <th class="p-name">Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>User Order</th>
                                    <th>Delete</th>
                                    <th>Edit Status</th>
                                </tr>
                            
                            </thead>
                            <tbody>
                          
                            <?php $__currentLoopData = $userInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                                <tr>
                                <td class="cart-pic first-row"><img src="<?php echo e(asset('assets/img/products/'.$u->Products['img'])); ?>" alt=""></td>
                                    <td class="cart-title first-row">
                                        <h5><?php echo e($u->Products['name']); ?></h5>
                                    </td>
                                    <td class="p-price first-row">₴<?php echo e($u->Products['prise']); ?></td>
                                    <td class="qua-col first-row">
                                        <div class="quantity">
                                            <div class="pro-qty">
                                                <input type="text" value="<?php echo e($u->quentities); ?>">
                                            </div>
                                        </div>
                                    </td>
                                   <td class="total-price first-row">₴<?php echo e($u->Products['prise']*$u->quentities); ?></td>
                                  <td class="p-price first-row"><?php echo e($u->status_order); ?></td>
                                    <td class="close-td first-row"><a onclick="return confirm('Do you really want to delete?')" href="#"><i class="fas fa-trash"></i></a></td>
                                    <td class="close-td first-row"><a href="<?php echo e(route('StatusOrder',$u->id)); ?>"><i class="fas fa-user-edit"></i><a></td>
                           
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Faq Section End -->
    <?php else: ?>
    
    <?php endif; ?><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Admin/Admin_content.blade.php ENDPATH**/ ?>