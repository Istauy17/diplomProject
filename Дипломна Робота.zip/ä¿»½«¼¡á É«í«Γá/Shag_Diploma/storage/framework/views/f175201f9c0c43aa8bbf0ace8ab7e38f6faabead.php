<section class="product-shop spad">
        <div class="container">
            <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-8 order-2 order-lg-1 produts-sidebar-filter">

            <?php if(session('admin_session')): ?>
                <button type="submit" class="btn btn-primary"><a style="margin:10px; color:crimson;" href="<?php echo e(route('AddAdminInfo')); ?>" class="filter-btn">Add Product</a></button> 
                <?php endif; ?>
                <form action="<?php echo e(route('Shop')); ?>" method="GET">
                
                    <div class="filter-widget">
                        <h4 class="fw-title">Categories</h4>
                        <!-- <ul class="filter-catagories"> -->
                        <div class="fw-brand-check">
                            <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bc-item">
                            <label>
                                    <?php echo e($c->name); ?>

                                    <input type="checkbox"  name="collection_id" value="<?php echo e($c->id); ?>">
                                    <span class="checkmark"></span>
                                </label></br>
                        </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <!-- </ul> -->
                    </div>
                    <div class="filter-widget">
                        <h4 class="fw-title">Brand</h4>
                        <div class="fw-brand-check">
                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bc-item">
                              
                                <label>
                                    <?php echo e($b->name); ?>

                                    <input type="checkbox"  name="brand_id" value="<?php echo e($b->id); ?>">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="filter-widget">
                        <h4 class="fw-title">Price</h4>
                        <div class="filter-range-wrap">
                            <div class="range-slider">
                                <div class="price-input">
                                    <input name="price_from" type="text" id="minamount">
                                    <input name="price_to" type="text" id="maxamount">
                                </div>
                            </div>
                            <div class="price-range ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                            data-min="0" data-max="100000">
                                <div class="ui-slider-range ui-corner-all ui-widget-header"></div>
                                <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                            </div>
                        </div>
                    </div>
                    <div class="filter-widget">
                        <h4 class="fw-title">Size</h4>
                        <div class="fw-size-choose">
                            <div class="sc-item">
                                <input type="radio" id="s-size">
                                <label for="s-size">s</label>
                            </div>
                            <div class="sc-item">
                                <input type="radio" id="m-size">
                                <label for="m-size">m</label>
                            </div>
                            <div class="sc-item">
                                <input type="radio" id="l-size">
                                <label for="l-size">l</label>
                            </div>
                            <div class="sc-item">
                                <input type="radio" id="xs-size">
                                <label for="xs-size">xs</label>
                            </div>
                        </div>
                    </div>
                    <div class="filter-widget">
                        <h4 class="fw-title">Tags</h4>
                        <div class="fw-tags">
                            <a href="#">Towel</a>
                            <a href="#">Shoes</a>
                            <a href="#">Coat</a>
                            <a href="#">Dresses</a>
                            <a href="#">Trousers</a>
                            <a href="#">Men's hats</a>
                            <a href="#">Backpack</a>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Accept</button>
                </div>
               
                </form>
                <?php $__currentLoopData = $cloth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-9 order-1 order-lg-2">
                            <div style=" display: flex ;" class="" >
                                <div class="">
                                    <div class="pi-pic">
                                        <img style="height:30%; width:100% ; " src="<?php echo e(asset('assets/img/products/'.$item->img)); ?>" alt="">
                                       
                                    </div>
     
                                </div> 
                              
                                 <div style="margin: 20px;" class="col-lg4">
                                    <h2 style="margin:5px;" ><?php echo e($item->name); ?></h2> 
                                    <div style="margin:5px;" class="catagory-name">Towel</div>
                                    <p><?php echo e($item->description); ?></p>
                                        <h2 style="margin:5px;" > Price : ₴<?php echo e($item->prise); ?></h2>
                         
                                 </div>   
                            </div> 
                            <div  class="cart-buttons">
                                <!-- <a style="margin:5px;" href="<?php echo e(route('Shop')); ?>" class="primary-btn continue-shop">Continue shopping</a> -->
                                <a style="margin:5px;" href="<?php echo e(route('AddToShopingCart',$item->id)); ?>" class="primary-btn up-cart">Add to cart</a>
                                <a style="margin:5px;" href="<?php echo e(route('AddFavorite',$item->id)); ?>" class="primary-btn ">Add to Favorite</a>
                                <?php if(session('admin_session')): ?>
                                <a style="margin:5px;" href="<?php echo e(route('EditAdminInfo',$item->id)); ?>" class="primary-btn up-cart">Edit Product</a>
                                <a style="margin:5px;" onclick="return confirm('Удалить?');" href="<?php echo e(route('DeleteAdminInfo',$item->id)); ?>" class="primary-btn up-cart">Delete Product</a>
                                <?php endif; ?>
                             
                            </div>
                            <section class="man-banner spad">
       
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="product-slider owl-carousel">
                    <?php $__currentLoopData = $productTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                        <div   class="product-item">
                            <div class="pi-pic">
                                <img style="width: 350px; height: 250px;" src="<?php echo e(asset('assets/img/products/'.$item->img)); ?>" alt="">                              
                                <div class="icon">
                                <a href="<?php echo e(route('AddFavorite',$item->id)); ?>"><i class="icon_heart_alt"></i></a>
                                </div>
                                <ul>
                                    <li class="w-icon active"><a href="<?php echo e(route('AddToShopingCart',$item->id)); ?>"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="<?php echo e(route('Description',['id'=>$item->id])); ?>">+ Quick View</a></li>
                                    
                                </ul>
                            </div>
                            <div class="pi-text">
                                <div class="catagory-name">Coat</div>
                                <a href="#">
                                    <h5><?php echo e($item->name); ?></h5>
                                </a>
                                <div class="product-price">
                                ₴<?php echo e($item->prise); ?>

                                </div>
                            </div>
                        </div>
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
                    </div>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                  <!-- Man Banner Section Begin -->
    
    <!-- Man Banner Section End -->
        
             </div>
          </div>
        </div>
    </section><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Description/Descriptions_content.blade.php ENDPATH**/ ?>