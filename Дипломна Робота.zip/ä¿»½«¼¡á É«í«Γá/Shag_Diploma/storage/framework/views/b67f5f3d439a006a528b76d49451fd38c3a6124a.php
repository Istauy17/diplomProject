<?php $__env->startSection('header'); ?>
<?php echo $__env->make('Head_FOOTER_Content.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('StatusOrder',$h->id)); ?>" method="POST">
<?php echo csrf_field(); ?>

<div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" name="status" class="form-control" id="inputEmail4" placeholder="Status Order"  value="<?php echo e($h->status_order); ?>">
    </div>
  
  
 

</div>
<div class="form-group">
 <button type="submit" class="btn btn-primary form-group">Accept</button>
 </div>
  
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('Head_FOOTER_Content.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Structure.main_ST1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Admin/StatusOrder.blade.php ENDPATH**/ ?>