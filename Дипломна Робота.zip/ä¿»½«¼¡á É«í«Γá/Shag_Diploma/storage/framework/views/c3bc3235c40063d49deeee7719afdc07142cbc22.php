  <!-- Header Section Begin -->
        <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-1 col-md-1">
                        <div class="logo">
                            <a href="<?php echo e(route('index_main')); ?>">
                                <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="">
                            </a>
                        </div>
                    </div>
                   
                    <div class="col-lg-7 col-md-6">
                        <div class="advanced-search">
                            <!-- <button type="button" class="category-btn">All Categories</button> -->
                           
                            <div class="input-group">
                            <form action="<?php echo e(route('Shop')); ?>" method="GET">
                                <input name="search_field" type="text" placeholder="What do you need?">
                                <button type="submit"><i class="ti-search"></i></button>
                                </form>
                            </div>
                           
                        </div>
                    </div>
                    
                    <div class="col-lg-1 text-right col-md-1">
                       
                   
                      
                </div>
                    
                    <div class="col-lg-3 text-right col-md-3">
                   
                        <ul class="nav-right">
                            <li class="heart-icon">
                                <a href="<?php echo e(route('Favorite')); ?>">
                                    <i class="icon_heart_alt"></i>
                                   
                                    <span><?php echo e($favorite_counter); ?></span>
                                    
                                </a>
                            </li>
                            <li class="cart-icon">
                                <a href="<?php echo e(route('ShopingCart')); ?>">
                                    <i class="icon_bag_alt"></i>
                                
                                    <span><?php echo e($order_counter); ?></span>
                            
                                </a>
                            
                                <div class="cart-hover">
                                <?php
                            $totalPrise=0;
                            ?> 
                            <?php $__currentLoopData = $hover_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $totalPrise+=$product->Products['prise'];
                            ?> 
                                    <div class="select-items">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td class="si-pic"><img src="assets/img/products/<?php echo e($product->Products['img']); ?>" alt=""></td>
                                                    <td class="si-text">
                                                        <div class="product-selected">
                                                            <p>₴<?php echo e($product->Products['prise']); ?>x <?php echo e($product->quentities); ?></p>
                                                            <h6>Kabino Bedside Table</h6>
                                                        </div>
                                                    </td>
                                                    <td class="si-close">
                                                        <i class="ti-close"></i>
                                                    </td>
                                                </tr>
                                    
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    <div class="select-total">
                                        <span>total:</span>
                                        <h5>₴<?php echo e($totalPrise); ?></h5>
                                    </div>
                                   
                                    <div class="select-button">
                                        <a href="<?php echo e(route('ShopingCart')); ?>" class="primary-btn view-card">VIEW CARD</a>
                                        <a href="<?php echo e(route('Chekout')); ?>" class="primary-btn checkout-btn">CHECK OUT</a>
                                    </div>
                                </div> 
                                
                            </li>
                            <li class="cart-price">₴<?php echo e($total); ?> </li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="nav-item">
            <div class="container">
                <div class="nav-depart">
        
                    
                </div>
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li class="active"><a href="<?php echo e(route('index_main')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('Shop')); ?>">Shop</a></li>
                        <li><a href="#">Collection</a>
                            <ul class="dropdown">
                                <li><a href="http://public/Shop?collection_id=1">Men's</a></li>
                                <li><a href="http://public/Shop?collection_id=2">Women's</a></li>
                                <li><a href="http://public/Shop?collection_id=3">Kid's</a></li>
                            </ul>
                        </li>
                        <?php if(session('admin_session')): ?>
                        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
                     
                        <?php endif; ?>
                        <li>
                        
                        <?php if(session('admin_session')): ?>
                        <a class="logo"  href="<?php echo e(route('admin.index')); ?>"  class="login-panel"><i style="font-size:18px ;" class="fas fa-user-circle"> </i>Account</a>
                        <?php else: ?>
                        <a class="logo"  href="<?php echo e(route('Account')); ?>"  class="login-panel"><i  style="font-size:18px ;" class="fas fa-user-circle"> </i>Account</a>
                        <?php endif; ?>

                        </li>
                        <?php if(Auth::check()): ?>
                        <li><li> <a href="<?php echo e(route('out')); ?>" class="login-panel"><i class="fa fa-user"></i>Logout</a></li>
                        <?php else: ?>
                        <li><li> <a href="<?php echo e(route('login')); ?>" class="login-panel"><i class="fa fa-user"></i>Login / Register</a></li>
                        <?php endif; ?>
                        
                        </li>
                        
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End --><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Head_FOOTER_Content/header.blade.php ENDPATH**/ ?>