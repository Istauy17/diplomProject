 <!-- Faq Section Begin -->
 <div class="faq-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="faq-accordin">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-heading active">
                                    <a class="active" data-toggle="collapse" data-target="#collapseOne">
                                        Personal Details
                                    </a>
                                </div>
                                <div id="collapseOne" class="collapse show" data-parent="#accordionExample">
                                    <section class="checkout-section spad">
                                        <div class="container">
                                        <?php $__currentLoopData = $user_in_session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infoUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                            <form action="<?php echo e(route('EditInfo')); ?>" method="POST" class="checkout-form">
                                                                                                    
                                            
                                             <?php echo csrf_field(); ?>      
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <h4>Personal Details</h4>
                                                         <div class="row">
                                                                                                             
                                                            <div class="col-lg-6">
                                                                <label for="fir">First Name<span>: <?php echo e($infoUser->firstname); ?> </span></label>
                                                            <div style="display:none" class="edit" ><input type="text" value="<?php echo e($infoUser->firstname); ?>" id="fir" name="firstname" required ></div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label for="last">Last Name<span>: <?php echo e($infoUser->lastname); ?></span></label>
                                                                <input type="text"style="display:none" class="edit"value="<?php echo e($infoUser->lastname); ?>" id="last" name="lastname"required>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="cun">Country<span>: <?php echo e($infoUser->country); ?></span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($infoUser->country); ?>" id="cun" name="country"required>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="street">Street Address<span>: <?php echo e($infoUser->address); ?></span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($infoUser->address); ?>" id="street"name="address"required class="street-first">
                                                              
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="zip">Postcode / ZIP<span>: <?php echo e($infoUser->postcode); ?></span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($infoUser->postcode); ?>" id="zip " name="postcode"required>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <label for="town">Town / City<span>: <?php echo e($infoUser->City); ?></span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($infoUser->City); ?>" id="town" name="city"required>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label for="email">Email Address<span>: <?php echo e($infoUser->email); ?></span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($infoUser->email); ?>" id="email" name="email"required>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label for="phone">Phone<span>:<br> <?php echo e($infoUser->phone); ?></span></label>
                                                                <input type="text" style="display:none" class="edit" value="<?php echo e($infoUser->phone); ?>" id="phone" name="phone"required>
                                                            </div>   
                                                                
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                        <div style="margin-left:20px;" class="order-btn">
                                                            <button type="submit"  class="site-btn place-btn">Save</button>
                                                           
                                                        </div>
                                                            
                                                           
                                                        </div>

                                                       
                                                       
                                                    </div>
                                                </div>
                                              
                                            </form>
                                             
                                            <div  style="margin-left:5px; margin-top:20px ;"class="order-btn">
                                                            <button id="edit_button" onclick="edit()" class="site-btn place-btn">Edit</button>
                                             </div>
                                        </div>
                                    </section>
                                </div>  
                            </div>
                         
                            <div class="card">
                                <div class="card-heading">
                                    <a data-toggle="collapse" data-target="#collapseTwo">
                                        History Journal
                                    </a>
                                </div>
                                <div id="collapseTwo" class="collapse" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <?php echo $__env->make('Account.History_journal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-heading">
                                    <a data-toggle="collapse" data-target="#collapseThree">
                                       Favorite Journal
                                    </a>
                                </div>
                                <div id="collapseThree" class="collapse" data-parent="#accordionExample">
                                    <div class="card-body">
                                    <?php echo $__env->make('Account.Favorite_journal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Faq Section End --><?php /**PATH C:\OpenServer\domains\Shag_Diploma\resources\views/Account/Account_content.blade.php ENDPATH**/ ?>