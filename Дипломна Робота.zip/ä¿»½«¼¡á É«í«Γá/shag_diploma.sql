-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 25 2021 г., 12:02
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shag_diploma`
--

-- --------------------------------------------------------

--
-- Структура таблицы `attendances`
--

CREATE TABLE `attendances` (
  `id` bigint(20) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `count` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `brands`
--

INSERT INTO `brands` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Calvin Klein', NULL, NULL),
(2, 'Diesel', NULL, NULL),
(3, 'Polo', NULL, NULL),
(4, 'Tommy Hilfiger', NULL, NULL),
(5, 'Adidas', NULL, NULL),
(6, 'Chanel', NULL, NULL),
(7, 'Sol\'s Imperial', NULL, NULL),
(8, 'Levi\'s', NULL, NULL),
(9, 'Columbia', NULL, NULL),
(10, 'Puma', NULL, NULL),
(11, 'Jack Wolfskin', NULL, NULL),
(12, 'Koton', NULL, NULL),
(13, 'Kappa', NULL, NULL),
(14, 'Alpine Crown', NULL, NULL),
(15, 'Love&Live', NULL, NULL),
(16, 'Befree', NULL, NULL),
(17, 'Jaklin', NULL, NULL),
(18, 'VOLVIS', NULL, NULL),
(19, 'Dino Vittorio', NULL, NULL),
(20, 'Lookie', NULL, NULL),
(21, 'Steve Madden', NULL, NULL),
(22, 'Reborn', NULL, NULL),
(23, 'Palmera', NULL, NULL),
(24, 'Parfois', NULL, NULL),
(25, 'Guess', NULL, NULL),
(26, 'Dior', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `checkouts`
--

CREATE TABLE `checkouts` (
  `id` bigint(20) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `PostCode` int(100) NOT NULL,
  `users_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `collections`
--

CREATE TABLE `collections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `collections`
--

INSERT INTO `collections` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Men', NULL, NULL),
(2, 'Women', NULL, NULL),
(3, 'Kids', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `favorites`
--

CREATE TABLE `favorites` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 4, 5, NULL, NULL),
(4, 4, 2, '2021-05-18 17:15:44', '2021-05-18 17:15:44'),
(7, 5, 3, '2021-05-20 14:46:43', '2021-05-20 14:46:43'),
(13, 7, 4, '2021-05-25 04:19:38', '2021-05-25 04:19:38'),
(14, 7, 2, '2021-05-25 04:28:02', '2021-05-25 04:28:02');

-- --------------------------------------------------------

--
-- Структура таблицы `histori_orders`
--

CREATE TABLE `histori_orders` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quentities` bigint(255) DEFAULT NULL,
  `total` bigint(255) DEFAULT NULL,
  `status_order` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `histori_orders`
--

INSERT INTO `histori_orders` (`id`, `user_id`, `product_id`, `quentities`, `total`, `status_order`, `created_at`, `updated_at`) VALUES
(7, 5, 2, 1, 350, 'wwwwewe', '2021-05-19 17:51:26', '2021-05-24 19:53:33'),
(8, 5, 3, 1, 670, 'Прийнято', '2021-05-19 17:51:26', '2021-05-25 05:43:37'),
(9, 5, 4, 1, 900, NULL, '2021-05-19 17:51:26', '2021-05-19 17:51:26'),
(10, 5, 5, 1, 290, NULL, '2021-05-19 17:51:26', '2021-05-19 17:51:26'),
(11, 5, 5, 1, 290, NULL, '2021-05-21 05:42:16', '2021-05-21 05:42:16'),
(12, 5, 2, 1, 350, NULL, '2021-05-21 05:50:18', '2021-05-21 05:50:18'),
(14, 5, 3, 1, 670, NULL, '2021-05-21 05:50:18', '2021-05-21 05:50:18'),
(15, 5, 6, 1, 1470, NULL, '2021-05-21 05:50:18', '2021-05-21 05:50:18'),
(16, 7, 2, 2, 350, NULL, '2021-05-25 05:30:21', '2021-05-25 05:30:21'),
(17, 7, 6, 5, 1470, NULL, '2021-05-25 05:30:21', '2021-05-25 05:30:21');

-- --------------------------------------------------------

--
-- Структура таблицы `img_content`
--

CREATE TABLE `img_content` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `img_content`
--

INSERT INTO `img_content` (`id`, `Name`, `type_id`) VALUES
(9, 'banner_Men.jpg', 8),
(10, 'banner-Women.jpg', 9),
(11, 'banner-Kids.jpg', 10),
(12, 'Mainbaner1.jpg', 11),
(13, 'Mainbaner2.jpg', 11),
(14, 'Mainbaner3.jpg', 11),
(15, 'time-bg.jpg', 14),
(16, 'man-large.jpg', 13),
(17, 'women-large.jpg', 12);

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2021_05_05_154834_create_brands_table', 1),
(2, '2021_05_05_154933_create_collections_table', 1),
(3, '2021_05_05_160657_create_roles_table', 1),
(4, '2021_05_05_184242_create_users_table', 2),
(5, '2021_05_05_184317_create_products_table', 3),
(6, '2021_05_05_185021_create_orders_table', 4),
(7, '2021_05_09_230527_create_favorites_table', 5),
(8, '2021_05_22_222534_create_tags_table', 6);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quentities` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `order_status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `quentities`, `total`, `order_status`, `created_at`, `updated_at`) VALUES
(24, 4, 2, 1, 350, 0, '2021-05-13 15:41:06', '2021-05-13 15:41:06'),
(47, 5, 2, 6, 350, 0, '2021-05-21 17:08:05', '2021-05-24 19:20:25'),
(48, 5, 12, 8, 1230, 0, '2021-05-21 17:12:20', '2021-05-24 19:20:35');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size_id` int(11) DEFAULT NULL,
  `prise` int(11) NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_id` bigint(20) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_id` bigint(20) UNSIGNED NOT NULL,
  `tag_id` bigint(20) UNSIGNED DEFAULT NULL,
  `counter` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `size_id`, `prise`, `img`, `collection_id`, `description`, `brand_id`, `tag_id`, `counter`, `created_at`, `updated_at`) VALUES
(2, 'Microfiber Wool Scarf', 2, 350, 'product-4.jpg', 2, 'Nice', 12, 1, 8, NULL, '2021-05-25 05:57:23'),
(3, 'Guangzhou sweater\r\n', 2, 670, 'product-2.jpg', 2, 'Nice', 2, NULL, 3, NULL, '2021-05-24 19:55:06'),
(4, 'Green Shirts', 4, 900, 'product-3.jpg', 1, '', 4, NULL, 4, NULL, '2021-05-23 18:45:51'),
(5, 'Converse Shoes\r\n', 2, 290, 'product-9.jpg', 3, 'Ok', 5, NULL, 2, NULL, '2021-05-25 04:03:02'),
(6, 'Sumka Calvin Klein Z245', 2, 1470, 'Sumka_CalvinK1.jpg', 2, 'Sumochka', 1, NULL, 1, NULL, '2021-05-23 18:42:38'),
(7, 'Sumka Zhinocha Kappa', 1, 2300, '2207171902_w640_h640_sumka-zhinocha-kappa.jpg', 2, '++', 13, NULL, NULL, NULL, NULL),
(10, 'Sumka Dior', 3, 5600, 'women-4-Dior.jpg', 2, '', 26, NULL, 6, NULL, '2021-05-23 18:46:28'),
(11, 'Men Yelow BackPack', 4, 999, 'man_BackPack-1.jpg', 1, '', 9, 7, 2, NULL, '2021-05-23 18:43:10'),
(12, 'CALVIN KLEIN JEANS SLIM', 4, 1230, 'calvin-klein-jeans-dzhinsi-j30j315568-cinii-slim-fit.jpg', 1, '', 1, NULL, NULL, NULL, NULL),
(17, 'Yelow Kepka', 2, 359, 'product-5.jpg', 1, 'Very Good Kepka', 18, 6, NULL, '2021-05-24 17:17:19', '2021-05-24 17:17:19'),
(18, 'Кроссовки Puma X-Ray 2 Square', 1, 1699, '177518447.jpg', 3, 'Размер 37 Назначение Для бега Сезон Весенняя Демисезонная Летняя Осенняя Цвет Белый Синий Материал верха Искусственная кожа Текстиль Материал подкладки Текстиль Мембрана Нет Материал подошвы Резина / EVA Информация о размерах Таблица соответствий  Гарантийные условия Подробнее Страна-производитель товара Китай Страна регистрации бренда Германия', 10, 2, 4, '2021-05-25 03:47:41', '2021-05-25 03:53:03');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', NULL, NULL),
(2, 'user', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `sizes`
--

CREATE TABLE `sizes` (
  `id` int(11) NOT NULL,
  `Name` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sizes`
--

INSERT INTO `sizes` (`id`, `Name`) VALUES
(1, 'S'),
(2, 'M'),
(3, 'L'),
(4, 'XL');

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `tags`
--

INSERT INTO `tags` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Towel', NULL, NULL),
(2, 'Shoes', NULL, NULL),
(3, 'Coat', NULL, NULL),
(4, 'Dresses', NULL, NULL),
(5, 'Trousers', NULL, NULL),
(6, 'Men\'s hats', NULL, NULL),
(7, 'Backpack', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `type_img`
--

CREATE TABLE `type_img` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `type_img`
--

INSERT INTO `type_img` (`id`, `Name`) VALUES
(8, 'Men'),
(9, 'Women'),
(10, 'Kids'),
(11, 'MainBaner'),
(12, 'WomenScrol'),
(13, 'MenScrol'),
(14, 'DealOfTheWeek');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `City` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `password`, `phone`, `address`, `role_id`, `country`, `postcode`, `City`, `created_at`, `updated_at`) VALUES
(4, 'Alexs', 'Brikssss', 'adgtasfjhsxfgj@gmail.com', '$2y$10$zlRO.3TKxR43tdQ0wuUhq.KomTGMl.xCfHI2iYGN1A/EDQLIL7Pz6', '1234567899', 'Baker St. 19/1', 2, 'Casta', 'qweerty123', 'Boston', '2021-05-07 15:54:28', '2021-05-25 05:58:25'),
(5, 'Nick', 'Nikelson', 'istauy171232@gmail.com', '$2y$10$P23zLNPCH3VEXoTpQ9eP0OwisHihWGf2hLMTZIAyb/F7kOJOFhmUe', '+380987654321', 'Aleksa Dovbusha 2/A', 2, 'Liviya', 'qweerty123', 'City', '2021-05-13 12:34:34', '2021-05-13 13:22:35'),
(6, 'Kolia', 'Temp', 'redo@gmail.ru', '$2y$10$MaAoemPfsHJveqYaj58XnelBW9bw.4f54WUe9Y5ErHgKD4pL9kpRC', '1234567878', 'Aleksa Dovbusha 2A', 1, 'Ukraine', '47779ewe', 'Khmel', '2021-05-23 19:56:06', '2021-05-24 14:46:54'),
(7, 'Nick', 'Vlasiuk', 'Istauy1712@gmail.com', '$2y$10$BPIHSS8pFktatlyEvY0XRu2yhf439F/f4HsLndKR3NJiUmEnmFIlC', '+380980393887', 'Chkalova 18', 2, 'Ukraine', NULL, NULL, '2021-05-25 03:55:52', '2021-05-25 03:55:52');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `attendances`
--
ALTER TABLE `attendances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `checkouts`
--
ALTER TABLE `checkouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`);

--
-- Индексы таблицы `collections`
--
ALTER TABLE `collections`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `favorites_user_id_foreign` (`user_id`),
  ADD KEY `favorites_product_id_foreign` (`product_id`);

--
-- Индексы таблицы `histori_orders`
--
ALTER TABLE `histori_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `histori_orders_ibfk_2` (`product_id`);

--
-- Индексы таблицы `img_content`
--
ALTER TABLE `img_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type_id` (`type_id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_product_id_foreign` (`product_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_collection_id_foreign` (`collection_id`),
  ADD KEY `products_brand_id_foreign` (`brand_id`),
  ADD KEY `size_id` (`size_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `type_img`
--
ALTER TABLE `type_img`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `attendances`
--
ALTER TABLE `attendances`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT для таблицы `checkouts`
--
ALTER TABLE `checkouts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `collections`
--
ALTER TABLE `collections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `histori_orders`
--
ALTER TABLE `histori_orders`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `img_content`
--
ALTER TABLE `img_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `type_img`
--
ALTER TABLE `type_img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `attendances`
--
ALTER TABLE `attendances`
  ADD CONSTRAINT `attendances_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Ограничения внешнего ключа таблицы `checkouts`
--
ALTER TABLE `checkouts`
  ADD CONSTRAINT `checkouts_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favorites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `histori_orders`
--
ALTER TABLE `histori_orders`
  ADD CONSTRAINT `histori_orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `histori_orders_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `img_content`
--
ALTER TABLE `img_content`
  ADD CONSTRAINT `img_content_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `type_img` (`id`);

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  ADD CONSTRAINT `products_collection_id_foreign` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`id`),
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`);

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
